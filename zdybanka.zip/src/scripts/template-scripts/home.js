// add swiper

new Swiper(".gallery-slider", {
  direction: "horizontal",
  slidesPerView: 3,
  spaceBetween: 30,
  dynamicBullets: true,
  dynamicMainBullets: 3,
  navigation: {
    nextEl: ".gallery__arrow-next",
    prevEl: ".gallery__arrow-prev",
  },
  loop: true,
  watchOverflow: true,
  pagination: {
    el: ".gallery__pagination",
    clickable: true,
  },
  autoHeight: false,
  breakpoints: {
    0: {
      slidesPerView: 1,
      dynamicBullets: true,
      dynamicMainBullets: 3,
    },
    768: {
      slidesPerView: 3,
      dynamicBullets: true,
      dynamicMainBullets: 3,
    },
    1920: {
      slidesPerView: 5,
    },
  },
});
