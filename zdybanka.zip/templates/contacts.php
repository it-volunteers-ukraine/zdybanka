<?php
/*
Template Name: contacts
*/
get_header();
?>
<h2>home page</h2>



<?php get_footer(); ?>