<?php
/*
Template Name: about
*/
get_header();
?>
<h2>about page</h2>



<?php get_footer(); ?>